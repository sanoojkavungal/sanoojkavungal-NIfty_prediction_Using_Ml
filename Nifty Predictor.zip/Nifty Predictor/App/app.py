from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load your trained model
model = joblib.load('stock_model.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get user inputs
        open_price = float(request.form['Open'])
        high_price = float(request.form['High'])
        low_price = float(request.form['Low'])
        close_price = float(request.form['Close'])

        # Format input for the model
        features = np.array([[open_price, high_price, low_price, close_price]])

        # Predict
        prediction = model.predict(features)[0]

        result = {
            'Next_Open': round(prediction[0], 2),
            'Next_High': round(prediction[1], 2),
            'Next_Low': round(prediction[2], 2),
            'Next_Close': round(prediction[3], 2)
        }

        return render_template('index.html', prediction=result)

    except Exception as e:
        return f"Error occurred: {e}"

if __name__ == '__main__':
    app.run(debug=True)
